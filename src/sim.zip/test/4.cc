#include <iostream>

int main()
{
  std::string myname;
}
