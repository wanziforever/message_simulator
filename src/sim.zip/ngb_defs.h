// Message simulator: tool for simulate internal message for
// NGB system
//
// Copyright (C) 2012, Hisense China R&D, Inc.
//
// the software is free to read and modification, but is restrict
// for any distribution, please contact the owner if have any
// questions.
//
// @Author wangliang8@hisense.com (denny)
// Version: 0.1 2012/09/29

#include <iostream>
